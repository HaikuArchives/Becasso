resource ('blog', 128, "Becasso")
{
	read ("becasso.dat")
}

resource ('slog', 129, "Sum")
{
	read ("sum.dat")
}